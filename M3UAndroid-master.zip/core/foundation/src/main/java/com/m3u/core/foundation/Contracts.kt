package com.m3u.core.foundation

object Contracts {
    const val PLAYER_ACTIVITY = "com.m3u.smartphone.ui.business.channel.PlayerActivity"
    const val PLAYER_SHORTCUT_CHANNEL_ID = "shortcut:channel-id"
    const val PLAYER_SHORTCUT_CHANNEL_RECENTLY = "shortcut:channel-recently"
}