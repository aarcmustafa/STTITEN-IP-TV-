package com.m3u.business.setting

import com.m3u.core.foundation.wrapper.Message
import com.m3u.i18n.R.string
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

sealed class SettingMessage(
    override val level: Int,
    override val type: Int,
    override val duration: Duration = 3.seconds,
    resId: Int,
    vararg formatArgs: Any
) : Message.Static(level, "setting", type, duration, resId, formatArgs) {
    data object EmptyTitle : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_error_empty_title
    )
    data object EmptyEpgTitle : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_error_empty_epg_title
    )
    data object EmptyEpg : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_error_empty_epg
    )

    data object EmptyUrl : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_error_blank_url
    )

    data object EmptyFile : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_error_unselected_file
    )

    data object FileAccessFailed : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_playlist_file_access_failed,
    )

    data object Enqueued : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_enqueue_subscribe
    )

    data object ProviderCredentialsRequired : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_provider_credentials_required
    )

    data object ProviderAdded : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_provider_added
    )

    data object ProviderSubscriptionFailed : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_provider_subscription_failed
    )

    data object EpgAdded : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_epg_added
    )

    data object PlaylistOperationFailed : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.ui_error_unknown,
    )

    data object RemoteTvNotConnected : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_remote_tv_not_connected
    )

    data object RemoteTvSubscribeSent : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_remote_subscribe_sent
    )

    data object RemoteTvSubscribeFailed : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_remote_subscribe_failed
    )

    data object BackingUp : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_backing_up
    )

    data object Restoring : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_restoring
    )

    data object ExtensionDataCleared : SettingMessage(
        level = LEVEL_INFO,
        type = TYPE_SNACK,
        resId = string.feat_setting_extension_data_cleared,
    )

    data object ExtensionOperationFailed : SettingMessage(
        level = LEVEL_ERROR,
        type = TYPE_SNACK,
        resId = string.feat_setting_extension_operation_failed,
    )
}
