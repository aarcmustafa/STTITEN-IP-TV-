@file:Suppress("UnstableApiUsage")

import com.android.build.api.dsl.ManagedVirtualDevice

plugins {
    alias(libs.plugins.androidx.baselineprofile)
    alias(libs.plugins.com.android.test)
}

android {
    namespace = "com.m3u.baselineprofile.smartphone"
    compileSdk = 37

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        minSdk = 28
        targetSdk = 34

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    testOptions.managedDevices.allDevices {
        create<ManagedVirtualDevice>("Pixel5Api34") {
            device = "Pixel 5"
            apiLevel = 34
            systemImageSource = "aosp"
        }
    }
    // Note that your module name may have different name
    targetProjectPath = ":app:smartphone"
}

// This is the configuration block for the Baseline Profile plugin.
// You can specify to run the generators on a managed devices or connected devices.
baselineProfile {
    managedDevices += "Pixel5Api34"
    useConnectedDevices = false
    enableEmulatorDisplay = System.getenv("CI") != "true"
}

androidComponents {
    onVariants { v ->
        v.instrumentationRunnerArguments.put(
            "targetAppId",
            "com.m3u.smartphone"
        )
    }
}

dependencies {
    implementation(libs.androidx.test.ext.junit)
    implementation(libs.androidx.test.espresso.espresso.core)
    implementation(libs.androidx.test.uiautomator.uiautomator)
    implementation(libs.androidx.benchmark.benchmark.macro.junit4)
}
